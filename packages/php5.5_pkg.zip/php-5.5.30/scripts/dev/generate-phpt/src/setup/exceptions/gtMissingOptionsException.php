<?php

 class gtMissingOptionsException extends RuntimeException
  {
  }

?>